feather.replace(); //icon feather simbol centang

$(function () {
    let owl = $(".owl-carousel");
        owl.owlCarousel({
            items: 3,
            margin: 32,
            autoWidth:true,
            loop: true,
            nav: true
        });
});